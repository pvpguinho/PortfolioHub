console.log('PortfolioHub - site loaded');
// Pequeno script para futuras interações